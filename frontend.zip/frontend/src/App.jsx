import { useCallback, useEffect, useMemo, useState } from 'react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api, getDashboard, getOverview, getRooms } from './services/api';
import StatCard from './components/StatCard';
import './App.css';

const fmt = (n) => Number(n ?? 0).toLocaleString(undefined, { maximumFractionDigits: 1 });
const currentSeason = () => { const m = new Date().getMonth() + 1; return [3, 4, 5, 6].includes(m) ? 'Summer' : [7, 8, 9, 10].includes(m) ? 'Monsoon' : 'Winter'; };

function StatusBadge({ status }) {
  const cls = status === 'Active' ? 'status-active' : status === 'Issue' ? 'status-issue' : 'status-inactive';
  return <span className={`status-badge ${cls}`}><span className="status-dot" />{status}</span>;
}

export default function App() {
  const [rooms, setRooms] = useState([]);
  const [overview, setOverview] = useState(null);
  const [selectedRoom, setSelectedRoom] = useState('ROOM-101');
  const [search, setSearch] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('');
  const [season, setSeason] = useState(currentSeason());
  const [limit, setLimit] = useState('350');
  const [duration, setDuration] = useState('15');
  const [roomIdInput, setRoomIdInput] = useState('');
  const [roomNameInput, setRoomNameInput] = useState('');
  const [newLimit, setNewLimit] = useState('350');
  const [newDuration, setNewDuration] = useState('15');
  const [roomSaving, setRoomSaving] = useState(false);
  const [showRoomForm, setShowRoomForm] = useState(false);

  const refresh = useCallback(async (roomId = selectedRoom) => {
    try {
      const [roomList, overviewData] = await Promise.all([getRooms(), getOverview()]);
      setRooms(roomList); setOverview(overviewData);
      const exists = roomList.some(r => r.id === roomId);
      if (!exists && roomList.length) {
        roomId = roomList[0].id;
        setSelectedRoom(roomId);
      }
      if (exists || roomList.length) {
        const result = await getDashboard(roomId);
        setData(result); setError('');
      } else { setData(null); setError('No rooms are registered yet. Add a room to begin.'); }
    } catch (e) {
      setError(e.response?.data?.detail || 'Cannot reach the API. Check that the backend and database are running.');
    } finally { setLoading(false); }
  }, [selectedRoom]);

  useEffect(() => { refresh(selectedRoom); const timer = setInterval(() => refresh(selectedRoom), 30000); return () => clearInterval(timer); }, [refresh, selectedRoom]);
  useEffect(() => {
    const selected = data?.settings?.find(s => s.season === season);
    if (selected) { setLimit(String(selected.daily_limit_litres)); setDuration(String(selected.continuous_flow_minutes)); }
  }, [data, season]);

  const selectedRoomInfo = rooms.find(r => r.id === selectedRoom);
  const filteredRooms = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rooms.filter(r => !q || r.id.toLowerCase().includes(q) || r.name.toLowerCase().includes(q));
  }, [rooms, search]);
  const chartData = [...(data?.readings || [])].reverse().map(r => ({ time: new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), litres: r.interval_volume_litres }));
  const seasonalData = data?.seasonal?.seasons || [];

  const saveSettings = async (event) => {
    event.preventDefault(); setSaving(true); setNotice('');
    try {
      await api.put(`/settings/${season}`, { daily_limit_litres: Number(limit), continuous_flow_minutes: Number(duration) }, { params: { room_id: selectedRoom } });
      setNotice(`${season} settings saved for ${selectedRoomInfo?.name || selectedRoom}.`); await refresh(selectedRoom);
    } catch (e) { setNotice(e.response?.data?.detail || 'Could not save settings.'); }
    finally { setSaving(false); }
  };

  const createRoom = async (event) => {
    event.preventDefault(); setRoomSaving(true); setNotice('');
    const id = roomIdInput.trim().toUpperCase();
    try {
      const response = await api.post('/rooms', { id, name: roomNameInput.trim() || `Room ${id.replace(/^ROOM-/, '')}`, daily_limit_litres: Number(newLimit), continuous_flow_minutes: Number(newDuration) });
      setNotice(`Room ${response.data.name} was saved. No sensor has been assigned yet.`);
      setRoomIdInput(''); setRoomNameInput(''); setShowRoomForm(false); setSelectedRoom(response.data.id);
      await refresh(response.data.id);
    } catch (e) { setNotice(e.response?.data?.detail || 'Could not create room. Check the ID and limit.'); }
    finally { setRoomSaving(false); }
  };

  const renameRoom = async (room) => {
    const name = window.prompt('Enter the display name for this room:', room.name);
    if (name === null || !name.trim() || name.trim() === room.name) return;
    try { await api.patch(`/rooms/${encodeURIComponent(room.id)}`, { name: name.trim() }); setNotice('Room name updated.'); await refresh(selectedRoom); }
    catch (e) { setNotice(e.response?.data?.detail || 'Could not update room name.'); }
  };

  const removeRoom = async (room) => {
    if (room.id === 'ROOM-101') {
      setNotice('The default room ROOM-101 is protected and cannot be removed.');
      return;
    }
    if (!window.confirm(`Remove ${room.name} (${room.id})? Rooms with historical readings or alerts cannot be deleted.`)) return;
    setNotice('');
    try {
      await api.delete(`/rooms/${encodeURIComponent(room.id)}`);
      const remaining = rooms.filter(r => r.id !== room.id);
      const nextRoomId = selectedRoom === room.id ? (remaining[0]?.id || '') : selectedRoom;
      setSelectedRoom(nextRoomId);
      setRooms(remaining);
      setNotice(`Room ${room.id} was removed.`);
      await refresh(nextRoomId);
    } catch (e) {
      setNotice(e.response?.data?.detail || 'Could not remove room.');
    }
  };

  const updateAlert = async (id, status) => { try { await api.patch(`/alerts/${id}`, { status }); await refresh(selectedRoom); } catch { setNotice('Could not update alert status.'); } };
  const runAnalysis = async () => { try { const r = await api.post('/anomaly-analysis', null, { params: { room_id: selectedRoom } }); setNotice(r.data.status === 'insufficient_data' ? `Analysis needs ${r.data.minimum_readings} readings; currently ${r.data.available_readings}.` : `Analysis completed using ${r.data.method}.`); } catch (e) { setNotice(e.response?.data?.detail || 'Anomaly analysis failed.'); } };

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-lockup"><div className="brand-mark"><span>A</span></div><div className="brand"><strong>AquaGuard</strong><span>HOSTEL WATER INTELLIGENCE</span></div></div>
      <div className="topbar-right"><span className="topbar-label">CENTRAL MONITORING</span><span className="topbar-separator"/><span className="live-dot"/><span>Prototype</span></div>
    </header>
    <main className="main-content">
      <section className="hero"><div><p className="eyebrow">HOSTEL WATER / CENTRAL OVERVIEW</p><h1>Hostel Water Management</h1><p className="hero-sub">Monitor room-wise consumption, water limits, and sensor health from one dashboard.</p></div><button className="button button-light" onClick={() => refresh(selectedRoom)}>↻ Refresh data</button></section>
      {error && <div className="banner banner-error">{error}</div>}
      {notice && <div className="banner">{notice}<button className="dismiss" onClick={() => setNotice('')}>×</button></div>}
      {loading && !overview ? <div className="loading">Loading hostel data…</div> : <>
        <section className="overview-grid">
          <StatCard label="Registered rooms" value={fmt(overview?.room_count)} unit="rooms" note="Rooms configured in the database" />
          <StatCard label="Active sensors" value={fmt(overview?.active_sensors)} unit="online" note="Recently reporting sensors" />
          <StatCard label="Sensor issues" value={fmt(overview?.sensor_issues)} unit="issues" note="Requires inspection" />
          <StatCard label="Today's measured usage" value={fmt(overview?.today_litres)} unit="L" note={`${fmt(overview?.pending_alerts)} unresolved alerts across rooms`} />
        </section>

        <section className="panel directory-panel">
          <div className="panel-heading directory-heading"><div><p className="eyebrow">ROOM DIRECTORY</p><h2>Rooms & device status</h2><p className="panel-subtitle">Select a room to view its allowance, usage, and alerts.</p></div><button className="button button-primary" onClick={() => setShowRoomForm(v => !v)}>{showRoomForm ? 'Cancel' : '+ Add room'}</button></div>
          {showRoomForm && <form className="room-create-form" onSubmit={createRoom}>
            <div className="form-title"><strong>Register a room</strong><span>No physical sensor is required at this stage.</span></div>
            <label>Room ID<input value={roomIdInput} onChange={e => setRoomIdInput(e.target.value)} placeholder="e.g. ROOM-102 or 102" pattern="[A-Za-z0-9_-]+" required maxLength={50}/></label>
            <label>Display name<input value={roomNameInput} onChange={e => setRoomNameInput(e.target.value)} placeholder="e.g. Boys Hostel · Room 102" maxLength={100}/></label>
            <label>Default daily allowance (L)<input type="number" min="1" max="100000" value={newLimit} onChange={e => setNewLimit(e.target.value)} required/></label>
            <label>Continuous-flow alert (min)<input type="number" min="1" max="1440" value={newDuration} onChange={e => setNewDuration(e.target.value)} required/></label>
            <button className="button button-primary" disabled={roomSaving}>{roomSaving ? 'Saving…' : 'Save room'}</button>
          </form>}
          <div className="table-toolbar"><label className="search-box"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search room number or name…"/></label><span className="table-count">{filteredRooms.length} rooms</span></div>
          <div className="table-scroll"><table className="data-table"><thead><tr><th>ROOM</th><th>SENSOR</th><th>STATUS</th><th>TODAY'S USAGE</th><th>DAILY LIMIT</th><th>OPEN ALERTS</th><th>ACTION</th></tr></thead><tbody>
            {filteredRooms.map(room => <tr key={room.id} className={selectedRoom === room.id ? 'selected-row' : ''}>
              <td><button className="room-link" onClick={() => setSelectedRoom(room.id)}>{room.name}</button><span className="cell-secondary">{room.id}</span></td>
              <td>{room.sensor_id || 'Not assigned'}<span className="cell-secondary">{room.last_seen_at ? `Last seen ${new Date(room.last_seen_at).toLocaleString()}` : 'No sensor telemetry'}</span></td>
              <td><StatusBadge status={room.sensor_status}/>{room.sensor_issue && <span className="issue-reason">{room.sensor_issue}</span>}</td>
              <td>{fmt(room.today_litres)} L</td><td>{fmt(room.daily_limit_litres)} L</td><td><span className={room.pending_alerts ? 'alert-number' : 'quiet-number'}>{room.pending_alerts}</span></td>
              <td><div className="room-actions"><button type="button" className="table-action" onClick={() => setSelectedRoom(room.id)}>View</button><button type="button" className="table-action muted-action" onClick={() => renameRoom(room)}>Rename</button><button type="button" className="table-action delete-action" disabled={room.id === 'ROOM-101'} title={room.id === 'ROOM-101' ? 'The default room is protected' : 'Remove room'} onClick={() => removeRoom(room)}>Remove</button></div></td>
            </tr>)}
            {!filteredRooms.length && <tr><td colSpan="7" className="table-empty">No matching rooms. Add a room to register its water allowance.</td></tr>}
          </tbody></table></div>
          <p className="table-footnote">A room without a sensor can still have a saved water allowance. Usage is measured only after sensor readings arrive.</p>
        </section>

        {data && <>
          <section className="section-title"><div><p className="eyebrow">SELECTED ROOM</p><h2>{data.room.name}</h2><p>{data.room.id} · room-level water monitoring</p></div><StatusBadge status={data.room.sensor_status}/></section>
          {data.room.sensor_issue && <div className={data.room.sensor_status === 'Issue' ? 'sensor-message sensor-message-issue' : 'sensor-message'}><strong>{data.room.sensor_status === 'Issue' ? 'Issue' : 'Sensor inactive'}:</strong> {data.room.sensor_issue}. Room configuration remains available; usage cannot be treated as live until a sensor reports.</div>}
          <section className="stats-grid room-stats"><StatCard label="Today's consumption" value={fmt(data.summary.today_litres)} unit="L" note={`Current season: ${data.summary.season}`}/><StatCard label="Daily allowance" value={fmt(data.summary.daily_limit_litres)} unit="L" note="Configured for this room and season"/><StatCard label="Remaining allowance" value={fmt(data.summary.remaining_litres)} unit="L" note="Allowance minus measured usage"/><StatCard label="Latest flow rate" value={data.summary.last_reading_at ? fmt(data.summary.latest_flow_rate_lpm) : '—'} unit={data.summary.last_reading_at ? 'L/min' : ''} note={data.summary.last_reading_at ? `Last reading ${new Date(data.summary.last_reading_at).toLocaleString()}` : 'No readings received yet'}/></section>
          <section className="content-grid"><article className="panel chart-panel"><div className="panel-heading"><div><p className="eyebrow">CONSUMPTION HISTORY</p><h2>Interval water usage</h2></div><span className="unit-pill">Litres / reading</span></div>{chartData.length ? <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData}><defs><linearGradient id="usageFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#168a82" stopOpacity={0.25}/><stop offset="100%" stopColor="#168a82" stopOpacity={0.02}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e6eaf0"/><XAxis dataKey="time" tick={{fontSize:11}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/><Tooltip/><Area type="monotone" dataKey="litres" stroke="#168a82" fill="url(#usageFill)" strokeWidth={2}/></AreaChart></ResponsiveContainer></div> : <div className="empty-state"><span>〰</span><strong>No consumption readings</strong><p>This room's water allowance is saved. Connect a sensor later or submit clearly labelled test readings during development.</p></div>}</article>
          <article className="panel seasonal-panel"><div className="panel-heading"><div><p className="eyebrow">SEASONAL BREAKDOWN</p><h2>Usage by season</h2></div></div><div className="chart-wrap small-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={seasonalData}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e6eaf0"/><XAxis dataKey="season" tick={{fontSize:11}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/><Tooltip/><Bar dataKey="total_litres" fill="#3f8e89" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div><p className="muted small-note">Historical readings only. Empty seasons are not evidence of zero real-world consumption.</p></article></section>
          <section className="content-grid lower-grid"><article className="panel settings-panel"><div className="panel-heading"><div><p className="eyebrow">ROOM CONFIGURATION</p><h2>Seasonal water limits</h2></div><span className="unit-pill">{data.room.id}</span></div><form onSubmit={saveSettings} className="settings-form"><label>Season<select value={season} onChange={e => setSeason(e.target.value)}><option>Summer</option><option>Monsoon</option><option>Winter</option></select></label><label>Daily allowance (litres)<input type="number" min="1" max="100000" step="1" value={limit} onChange={e => setLimit(e.target.value)} required/></label><label>Continuous-flow alert (minutes)<input type="number" min="1" max="1440" value={duration} onChange={e => setDuration(e.target.value)} required/></label><button className="button button-primary" disabled={saving}>{saving ? 'Saving…' : 'Save seasonal limit'}</button></form><p className="muted small-note">Limits can be configured before a sensor is installed. Sensor-specific calibration will be configured when hardware is connected.</p></article>
          <article className="panel alerts-panel"><div className="panel-heading"><div><p className="eyebrow">ATTENTION REQUIRED</p><h2>Room alerts</h2></div><span className="count-pill">{(data.alerts || []).filter(a => a.status !== 'Resolved').length} open</span></div>{data.alerts?.length ? <div className="alert-list">{data.alerts.slice(0,8).map(alert => <div className="alert-row" key={alert.id}><div className={`alert-icon ${alert.severity === 'high' ? 'high' : ''}`}>!</div><div className="alert-body"><strong>{alert.alert_type.replaceAll('_',' ')}</strong><p>{alert.message}</p><span>{new Date(alert.created_at).toLocaleString()}</span></div><select aria-label={`Status for alert ${alert.id}`} value={alert.status} onChange={e => updateAlert(alert.id,e.target.value)}><option>Pending</option><option>Investigating</option><option>Resolved</option></select></div>)}</div> : <div className="empty-alerts"><span>✓</span><strong>No alerts recorded</strong><p>Alerts will appear when configured rules are triggered.</p></div>}</article></section>
          <section className="bottom-actions"><div><strong>Analysis tools</strong><p>Available for saved readings; no sensor hardware is required to configure rooms.</p></div><button className="button button-light" onClick={runAnalysis}>Run anomaly analysis</button></section>
        </>}
      </>}
      <footer><span>AquaGuard · B.Tech major project prototype</span><span>Sensor issues require human investigation · No automatic valve control</span></footer>
    </main>
  </div>;
}
