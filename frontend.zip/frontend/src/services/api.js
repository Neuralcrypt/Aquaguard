import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api',
  timeout: 8000,
});

export const getRooms = async () => (await api.get('/rooms')).data;
export const getOverview = async () => (await api.get('/overview')).data;
export const getDashboard = async (roomId) => {
  const params = { room_id: roomId };
  const [summary, readings, alerts, settings, seasonal, room] = await Promise.all([
    api.get('/summary', { params }),
    api.get('/readings', { params: { ...params, limit: 40 } }),
    api.get('/alerts', { params }),
    api.get('/settings', { params }),
    api.get('/seasonal-analysis', { params }),
    api.get(`/rooms/${encodeURIComponent(roomId)}`),
  ]);
  return { summary: summary.data, readings: readings.data, alerts: alerts.data, settings: settings.data, seasonal: seasonal.data, room: room.data };
};
